# Strapi plugin stb-dashboard

A quick description of stb-dashboard.
# stb-dashboard
