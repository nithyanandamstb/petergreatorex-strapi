'use strict';

const myService = require('./my-service');
const stbDashboardService = require('./stb-dashboard-service');
const dataBaseService = require('./database.services');

module.exports = {
  myService,
  stbDashboardService,
  dataBaseService
};
