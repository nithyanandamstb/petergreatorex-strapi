'use strict';
const stbDashBoard = require("./stb-dashboard/index");
module.exports = {
    "stb-dashboard":stbDashBoard
};
