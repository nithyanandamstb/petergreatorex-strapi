'use strict';

const myController = require('./my-controller');
const stbDashboardCtrl = require('./stb-dashboard-ctrl');

module.exports = {
  myController,
  stbDashboardCtrl
};
