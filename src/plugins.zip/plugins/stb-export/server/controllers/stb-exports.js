'use strict';

module.exports = ({ strapi }) => ({
  get_all_collections(ctx) {
    return "welocome";
  },
});
