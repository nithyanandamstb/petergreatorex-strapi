'use strict';

const myController = require('./my-controller');
const stbExports = require('./stb-exports');

module.exports = {
  myController,
  stbExports,
};
