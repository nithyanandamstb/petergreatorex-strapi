module.exports = [
  {
    method: 'GET',
    path: '/',
    handler: 'myController.index',
    config: {
      policies: [],
      auth:false
    },
  },
  {
    method: 'GET',
    path: '/get-all-collections',
    handler: 'stbExports.get_all_collections',
    config: {
      policies: [],
      auth:false
    },
  },
];
