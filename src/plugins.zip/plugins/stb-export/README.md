# Strapi plugin stb-export

A quick description of stb-export.
