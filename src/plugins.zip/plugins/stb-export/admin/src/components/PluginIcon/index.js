/**
 *
 * PluginIcon
 *
 */

import React from 'react';
import Puzzle from '@strapi/icons/Puzzle';

const PluginIcon = () => <Puzzle />;

export default PluginIcon;
